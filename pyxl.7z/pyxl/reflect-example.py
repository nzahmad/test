import xlloop
from math import exp, pi, log, sqrt
import scipy.stats as st
import time


# All arguments to expose are optional. Could use '@expose()' instead.
@xlloop.memoize
@xlloop.expose(excel_name='grid', arg_descrs=['arr is a range of numbers to sum'])
def test_grid(x=0, y=0):
    print('start')
    x = int(x)
    y = int(y)
    ans =  [[i+j for i in range(x)] for j in range(y)]
    print('end')
    return ans
    # r = []
    # for i in range(x):
    #     r.append([i+j for j in range(y)])
    # return r


#//==================================================================
#//Purpose: Garman Kolhagen (1983) currency option model
#//==================================================================

@xlloop.expose(excel_name='PY.GK', arg_descrs=['Garman Kolhagen (1983) currency option model'])
def GK(strOutputType, CallPut, dblS, dblK, dblR_dom, dblR_for, dblT, dblSigma):
    intPhi = 0
    if str(CallPut).upper() == "C":
        intPhi = 1
    elif str(CallPut).upper() == "P":
        intPhi = -1
    else:
        return 0

    cdf = st.norm.cdf
    pdf = st.norm.pdf

    d1 = (log(dblS / dblK) + (dblR_dom - dblR_for + 0.5 * dblSigma * dblSigma) * dblT) / (dblSigma * sqrt(dblT))
    d2 = d1 - dblSigma * sqrt(dblT)
    dblOptValue = intPhi * (dblS * exp(-dblR_for * dblT) * cdf(intPhi * d1) - dblK * exp(-dblR_dom * dblT) * cdf(intPhi * d2))

    type = str(strOutputType).lower()
    if type == "value": #//option value in domestic currency
        return dblOptValue
    elif type == "delta_spot": #//change in V wrt to unit change in S
        return intPhi * exp(-dblR_for * dblT) * cdf(intPhi * d1)
    elif type == "delta_pi": #//change in V computed in foreign currency wrt to unit change in S
        return intPhi * dblK / dblS * exp(-dblR_dom * dblT) * cdf(intPhi * d2)
    elif type ==  "delta_fwd": #//change in V wrt to unit change in F
        return intPhi * cdf(intPhi * d1)
    elif type == "elasticity":   #//percentage change in V wrt percentage change in S
        return intPhi * exp(-dblR_for * dblT) * cdf(intPhi * d1) * dblS / dblOptValue
    elif type == "gamma":        #//change in delta wrt unit change in S
        return exp(-dblR_for * dblT) * pdf(d1) / (dblS * dblSigma * sqrt(dblT)) * dblS / 100
    elif type == "speed":        #//change in gamma wrt unit change in S
        return exp(-dblR_for * dblT) * pdf(d1) / ((dblS**2) * dblSigma * sqrt(dblT)) * (d1 / (dblSigma * sqrt(dblT)) + 1)
    elif type == "theta":        #//change in V wrt unit change in T
        return (-exp(-dblR_for * dblT) * dblS * pdf(d1) * dblSigma / (2 * sqrt(dblT)) + intPhi * (dblR_for * dblS * exp(-dblR_for * dblT) * pdf(intPhi * d1) - intPhi * dblR_dom * dblK * exp(-dblR_dom * dblT) * pdf(intPhi * d2))) / 365
    elif type == "vega":         #//change in V wrt unit change in Sigma
        return dblS * exp(-dblR_for * dblT) * sqrt(dblT) * pdf(d1) / 100
    elif type == "volga":        #//change in Vega wrt unit change in Sigma
        return dblS * exp(-dblR_for * dblT) * sqrt(dblT) * pdf(d1) * d1 * d2 / dblSigma
    elif type == "vanna":        #//change in Vega wrt unit change in S
        return -exp(-dblR_for * dblT) * pdf(d1) * d2 / dblSigma
    elif type == "rho_dom":      #//change in V wrt unit change in R_dom
        return intPhi * dblK * dblT * exp(-dblR_dom * dblT) * cdf(intPhi * d2)
    elif type == "rho_for":      #//change in V wrt unit change in R_for
        return -intPhi * dblS * dblT * exp(-dblR_for * dblT) * cdf(intPhi * d1)
    else:
        return 0



#//==================================================================
#// Cumulative normal distribution function, N(x)
#//==================================================================
def jt_cdf(dblX):
    a1 = 0.31938153
    a2 = -0.356563782
    a3 = 1.781477937
    a4 = -1.821255978
    a5 = 1.330274429

    L = abs(dblX)
    K = 1 / (1 + 0.2316419 * L)
    result = 1 - 1 / (sqrt(2 * pi())) * exp(-L**2 / 2) * (a1 * K + a2 * K**2 + a3 * K**3 + a4 * K**4 + a5 * K**5)

    if dblX < 0:
        return 1 - result
    else:
        return result


#//==================================================================
#//Standard normal probability density function, N'(x)
#//==================================================================
def jt_pdf(dblX):
    return 1 / (sqrt(2 * pi)) * exp(-dblX * dblX / 2)

xlloop.run(5454)